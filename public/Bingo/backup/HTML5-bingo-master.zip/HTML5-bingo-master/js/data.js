
var headerText = "Bingo";

var footerText = "<a href='https://github.com/jeffehobbs/HTML5-bingo/' target='_blank'>Code available on github</a>";

var winText = "Winner";

var clickSnd = new Audio("audio/click.mp3");

var winSnd = new Audio("audio/win.mp3");

var JSONBingo = {"squares": [
        {"square": "one"},
        {"square": "two"},
        {"square": "three"},
        {"square": "four"},
        {"square": "five"},
        {"square": "six"},
        {"square": "seven"},
        {"square": "eight"},
        {"square": "nine"},
        {"square": "ten"},
        {"square": "eleven"},
        {"square": "twelve"},
        {"square": "thirteen"},
        {"square": "fourteen"},
        {"square": "fifteen"},
        {"square": "sixteen"},
        {"square": "seventeen"},
        {"square": "eighteen"},
        {"square": "nineteen"},
        {"square": "twenty"},
        {"square": "twenty one"},
        {"square": "twenty two"},
        {"square": "twenty three"},
        {"square": "twenty four"},    	
        {"square": "twenty five"},    	
        {"square": "twenty six"},    	
        {"square": "twenty seven"}, 
        {"square": "twenty eight"},    	
        {"square": "twenty nine"},    	
        {"square": "thirty"}    	
    ]
};
