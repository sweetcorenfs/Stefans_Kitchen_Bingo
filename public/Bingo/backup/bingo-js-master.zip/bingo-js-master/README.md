# bingo-js
Final project in my second year Intro to Web Development class. It's single player bingo so it's pretty boring tbh but was helpful in learning javascript.
